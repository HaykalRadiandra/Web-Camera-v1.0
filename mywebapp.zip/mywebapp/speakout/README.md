Jangan hapus atau ubah folder inc atau file .js baik di folder js atau di file .php
